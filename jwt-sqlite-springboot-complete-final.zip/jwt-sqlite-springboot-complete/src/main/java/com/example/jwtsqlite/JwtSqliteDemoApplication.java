package com.example.jwtsqlite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtSqliteDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(JwtSqliteDemoApplication.class, args);
    }
}


//https://repo1.maven.org/maven2/{groupId with /}/{artifactId}/{version}/{artifactId}-{version}.jar
