package com.example.jwtsqlite;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ExternalController {

    private final RestTemplate restTemplate = new RestTemplate();

    @GetMapping("/external")
    public String callExternalApi() {
        String url = "https://jsonplaceholder.typicode.com/posts/1";
        return restTemplate.getForObject(url, String.class);
    }
}
