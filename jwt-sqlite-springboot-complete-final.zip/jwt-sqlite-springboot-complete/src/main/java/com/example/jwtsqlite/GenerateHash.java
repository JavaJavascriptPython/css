package com.example.jwtsqlite;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public class GenerateHash {
    public static void main(String[] args) {
        PasswordEncoder encoder = new BCryptPasswordEncoder();
        String raw = "password123";
        String hash = encoder.encode(raw);
        System.out.println("BCrypt hash for '" + raw + "' is:");
        System.out.println(hash);
    }
}
