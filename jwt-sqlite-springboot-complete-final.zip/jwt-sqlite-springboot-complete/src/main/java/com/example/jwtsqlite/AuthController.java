package com.example.jwtsqlite;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final UserRepository userRepository;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;

    public AuthController(UserRepository userRepository, JwtUtil jwtUtil, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.jwtUtil = jwtUtil;
        this.passwordEncoder = passwordEncoder;
    }

    // ------------------ REGISTER ------------------
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String rawPassword = request.get("password");
        String role = request.getOrDefault("role", "USER");

        if (username == null || rawPassword == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Username or password missing");
        }

        // Encode password using BCrypt
        String encodedPassword = passwordEncoder.encode(rawPassword);

        // Save user to DB
        userRepository.saveUser(username, encodedPassword, role);

        System.out.println("[DEBUG] Registered user: " + username + ", role: " + role);
        return ResponseEntity.ok("User registered");
    }

    // ------------------ LOGIN ------------------
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        String rawPassword = request.get("password");

        if (username == null || rawPassword == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Username or password missing");
        }

        UserEntity user = userRepository.findByUsername(username);

        if (user == null) {
            System.out.println("[DEBUG] User not found: " + username);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }

        System.out.println("[DEBUG] Found user: " + username);
        System.out.println("[DEBUG] Stored password hash: " + user.getPassword());
        System.out.println("[DEBUG] Raw password from request: " + rawPassword);

        if (!passwordEncoder.matches(rawPassword, user.getPassword())) {
            System.out.println("[DEBUG] Password does NOT match for user: " + username);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }

        System.out.println("[DEBUG] Password matches for user: " + username);

        // Generate JWT token
        String token = jwtUtil.generateToken(user.getUsername(), user.getRole());

        return ResponseEntity.ok(Map.of("token", token));
    }
}
