package com.example.jwtsqlite;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;

@Repository
public class UserRepository {
    private final JdbcTemplate jdbcTemplate;

    public UserRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
        createTableIfNotExists();
    }

    private void createTableIfNotExists() {
        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, password TEXT NOT NULL, role TEXT NOT NULL)");
    }

    public void saveUser(String username, String password, String role) {
        jdbcTemplate.update("INSERT OR REPLACE INTO users (username, password, role) VALUES (?, ?, ?)", username, password, role);
    }

    public UserEntity findByUsername(String username) {
        List<UserEntity> users = jdbcTemplate.query("SELECT username, password, role FROM users WHERE username = ?", userRowMapper, username);
        return users.isEmpty() ? null : users.get(0);
    }

    public List<GrantedAuthority> getAuthoritiesByUsername(String username) {
        UserEntity user = findByUsername(username);
        if (user != null) {
            return List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole()));
        }
        return Collections.emptyList();
    }

    private final RowMapper<UserEntity> userRowMapper = (rs, rowNum) -> new UserEntity(rs.getString("username"), rs.getString("password"), rs.getString("role"));
}



