package com.example.jwtsqlite;



import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public class PasswordTest {
    public static void main(String[] args) {
        PasswordEncoder encoder = new BCryptPasswordEncoder();
        String raw = "password123";
        String hash = "$2a$10$9IQK1EKtiIHRXQgY4QC1.uQy8Z4/mX3cZVoUqqK.BnGuO7rfLLpzW";
        System.out.println("Password matches? " + encoder.matches(raw, hash));
    }
}


